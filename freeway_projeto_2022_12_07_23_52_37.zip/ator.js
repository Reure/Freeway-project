//ATOR
let xAtor = 85;
let yAtor = 366;
let colisao = false;
let meusPontos = 0;

function mostraAtor(){
  image(imagemAtor, xAtor, yAtor, 30,30);
}

function movimentaAtor(){
  if(keyIsDown(UP_ARROW)){
    yAtor -=3;
  }
  if(keyIsDown(DOWN_ARROW)){
    if(podeMover())
    yAtor +=3;
  }
}
function verificaColisao(){ 
  //collideRectCircle(x1, y1, width1, height1, cx, cy, diameter)
  
  for(let i = 0; i < imagemCarros.length; i++){
   colisao = collideRectCircle(xCarros[i],yCarros[i],comprimentoCarro, alturaCarro, xAtor, yAtor, 15)
    if(colisao){
      voltaAtor();
      somDaColisao.play(); 
      if(meusPontos > 0){
        meusPontos --;
      }
      
    }
  }
}

function voltaAtor(){
  yAtor = 366;
}

function incluiPontos(){
  textAlign(CENTER);
  textSize(25);
  text(meusPontos, width / 5, 27)
  fill(255,240,60);
}

function marcaPonto(){
  if(yAtor < 15){
    somDoPonto.play();
    meusPontos++;
    voltaAtor();
  }
}

function podeMover(){
    return yAtor < 366;
}